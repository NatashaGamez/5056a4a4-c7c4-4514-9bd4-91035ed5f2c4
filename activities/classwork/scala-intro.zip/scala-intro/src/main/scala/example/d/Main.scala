package example.d

object Main {

}
