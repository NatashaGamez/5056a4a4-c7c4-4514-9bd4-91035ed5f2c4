package example.b.model

case class Person() {

}
