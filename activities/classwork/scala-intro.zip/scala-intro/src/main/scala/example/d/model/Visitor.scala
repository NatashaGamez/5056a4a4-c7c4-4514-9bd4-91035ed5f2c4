package example.d.model

trait Visitor {

}
