package example.a

object Main {

}
