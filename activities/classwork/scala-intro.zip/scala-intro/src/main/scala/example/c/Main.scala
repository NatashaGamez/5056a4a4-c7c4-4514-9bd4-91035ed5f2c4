package example.c

object Main {

}
