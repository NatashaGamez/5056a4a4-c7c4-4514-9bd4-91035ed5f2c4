package example.b

object Main {

}
